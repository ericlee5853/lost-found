// src/components/Field.jsx
// 상세·수정 화면 표의 "항목 이름(th) + 값(td)" 한 쌍.
// 표 한 줄은 이런 쌍 3개(= 6칸)로 이루어진다.

/**
 * @param {string} label   항목 이름
 * @param {boolean} required 필수 입력 표시(*) 여부
 * @param {number} span    값 칸이 차지할 칸 수 (특징처럼 넓게 쓸 때 5)
 * @param {string} value   읽기 전용으로 보여줄 값 (children 이 없을 때 사용)
 * @param {React.ReactNode} children 입력 요소 (수정 화면에서 사용)
 */
export default function Field({ label, required, span, value, children }) {
  return (
    <>
      <th>{label}{required && <span className="required-mark"> *</span>}</th>
      <td colSpan={span}>{children ?? (value || "-")}</td>
    </>
  );
}
