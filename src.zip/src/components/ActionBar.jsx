// src/components/ActionBar.jsx
// 상세·수정 화면 맨 아래의 버튼 줄. 오른쪽 정렬에 위쪽 여백을 둔다.

export default function ActionBar({ children }) {
  return <div className="action-bar">{children}</div>;
}
