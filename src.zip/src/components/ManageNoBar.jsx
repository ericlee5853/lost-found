// src/components/ManageNoBar.jsx
// 상세·수정 화면에서 관리번호를 보여 주는 줄.
// 목록 페이지의 "전체 n건" 줄과 같은 자리·같은 모양이다.

export default function ManageNoBar({ manageNo }) {
  return (
    <div className="table-toolbar">
      <div className="toolbar-left">
        <span className="record-no-label">관리번호</span>
        <span className="record-no">{manageNo}</span>
      </div>
    </div>
  );
}
