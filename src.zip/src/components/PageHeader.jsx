// src/components/PageHeader.jsx
// 화면 위쪽의 제목 줄. 목록 페이지와 같은 모양을 쓴다.
// 버튼을 넘기지 않으면 제목만 나온다. (상세·수정 화면은 버튼이 아래쪽 ActionBar 에 있다.)

/**
 * @param {string} title 화면 제목
 * @param {React.ReactNode} [children] 오른쪽에 놓을 버튼들
 */
export default function PageHeader({ title, children }) {
  return (
    <div className="topbar">
      <h1 className="topbar-title">{title}</h1>
      {children && <div className="topbar-buttons">{children}</div>}
    </div>
  );
}
