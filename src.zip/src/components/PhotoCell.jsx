// src/components/PhotoCell.jsx
// 상세·수정 화면 표의 맨 왼쪽 사진 칸.
// 여러 줄에 걸쳐 있으므로 표의 첫 줄에 rowSpan 과 함께 넣는다.
// (분실물관리대장에만 쓰고, 분실신고에는 사진을 붙이지 않는다.)

/**
 * @param {string} image     사진 Base64 문자열 (없으면 빈 칸 표시)
 * @param {number} rowSpan   이 칸이 걸칠 표의 줄 수
 * @param {function} [onPick]   파일 선택 처리 (없으면 업로드 UI를 숨김 = 읽기 전용)
 * @param {function} [onRemove] 사진 삭제 처리
 */
export default function PhotoCell({ image, rowSpan, onPick, onRemove }) {
  return (
    <td className="record-photo-cell" rowSpan={rowSpan}>
      {image
        ? <img src={image} alt="물품 사진" className="record-image" />
        : <div className="record-photo-empty">사진</div>}
      {onPick && (
        <div className="record-photo-actions">
          <input type="file" accept="image/*" onChange={onPick} />
          {image && (
            <button type="button" className="btn small danger" onClick={onRemove}>
              사진 삭제
            </button>
          )}
        </div>
      )}
    </td>
  );
}
