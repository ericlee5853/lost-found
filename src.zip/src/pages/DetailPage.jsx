import { useNavigate, useParams } from "react-router-dom";
import { getFoundItem, getLostReport } from "../storage";
import { getCategoryName, getResultName, getExpireAction } from "../settings";
import Field from "../components/Field";
import PhotoCell from "../components/PhotoCell";
import PageHeader from "../components/PageHeader";
import ManageNoBar from "../components/ManageNoBar";
import ActionBar from "../components/ActionBar";
import NotFoundBox from "../components/NotFoundBox";

/**
 * 분실물 / 분실신고 상세 보기.
 * 목록 페이지와 같은 표 모양으로 항목을 늘어놓는다.
 * @param {"found"|"lost"} type 어느 대장의 데이터인지
 */
export default function DetailPage({ type }) {
  const navigate = useNavigate();
  const { manageNo } = useParams();

  const isFound = type === "found";
  const it = isFound ? getFoundItem(manageNo) : getLostReport(manageNo);

  if (!it) return <NotFoundBox manageNo={manageNo} />;

  // 이름은 저장된 id 로 설정 테이블에서 가져온다(규칙 1).
  // 보관기한은 등록 시점에 저장된 값을 그대로 보여 준다(규칙 3).
  const categoryName = getCategoryName(it.category_id);
  const editPath = isFound ? `/found/${manageNo}/edit` : `/lost/${manageNo}/edit`;

  return (
    <div className="page">
      <PageHeader title={isFound ? "분실물 상세" : "분실 신고 상세"} />

      <ManageNoBar manageNo={it.manageNo} />

      <table className="grid record-grid">
        <tbody>
          {isFound && (
            <>
              <tr>
                {/* 사진은 분실물관리대장에만 있고, 항목 4줄 + 특징 1줄에 걸친다. */}
                <PhotoCell image={it.image} rowSpan={5} />
                <Field label="물품 구분" value={categoryName} />
                <Field label="물품명" value={it.itemName} />
                <Field label="보관장소" value={it.storagePlace} />
              </tr>
              <tr>
                <Field label="접수일" value={it.receivedDate} />
                <Field label="습득일" value={it.foundDate} />
                <Field label="보관기한" value={it.deadline} />
              </tr>
              <tr>
                <Field label="소유자" value={it.owner} />
                <Field label="소유자 연락처" value={it.ownerContact} />
                <Field label="연락여부" value={it.contacted} />
              </tr>
              <tr>
                <Field label="처리결과" value={getResultName(it.result_id)} />
                <Field label="기간 만료 시 조치 방법" value={getExpireAction(it.category_id)} />
                <Field label="확인자" value={it.checker} />
              </tr>
            </>
          )}

          {!isFound && (
            <>
              <tr>
                <Field label="물품 구분" value={categoryName} />
                <Field label="물품명" value={it.itemName} />
                <Field label="처리 상태" value={it.status} />
              </tr>
              <tr>
                <Field label="접수일" value={it.receivedDate} />
                <Field label="습득일" value={it.foundDate} />
                <Field label="처리일" value={it.processedDate} />
              </tr>
              <tr>
                <Field label="소유자" value={it.owner} />
                <Field label="소유자 연락처" value={it.ownerContact} />
                <Field label="확인자" value={it.checker} />
              </tr>
            </>
          )}

          <tr>
            <Field label="특징" value={it.feature} span={5} />
          </tr>
        </tbody>
      </table>

      <ActionBar>
        <button className="btn" onClick={() => navigate("/")}>목록</button>
        <button className="btn primary" onClick={() => navigate(editPath)}>수정</button>
      </ActionBar>
    </div>
  );
}
