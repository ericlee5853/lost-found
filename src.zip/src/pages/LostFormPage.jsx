import { useNavigate, useParams } from "react-router-dom";
import {
  addLostReport, getLostReport, updateLostReport, deleteLostReport,
  peekLostManageNo,
} from "../storage";
import { itemCategoryTable, optionsFor } from "../settings";
import { STAFF_NAMES, PROCESS_STATUSES } from "../constants";
import { formatPhone } from "../imageUtil";
import { today } from "../dateUtil";
import { useRecordForm } from "../useRecordForm";
import Field from "../components/Field";
import PageHeader from "../components/PageHeader";
import ManageNoBar from "../components/ManageNoBar";
import ActionBar from "../components/ActionBar";
import NotFoundBox from "../components/NotFoundBox";

/**
 * 새 분실 신고 화면의 초기값.
 * 물품구분은 이름이 아니라 id 로 담는다. 분실신고에는 사진을 붙이지 않는다.
 */
function emptyForm() {
  return {
    receivedDate: today(), foundDate: today(), category_id: "", itemName: "",
    feature: "", owner: "", ownerContact: "", status: PROCESS_STATUSES[0],
    processedDate: "", checker: "",
  };
}

/** 필수 입력 항목과 안내 문구 */
const REQUIRED_FIELDS = [
  ["receivedDate", "접수일을 입력하세요."],
  ["foundDate", "습득일을 입력하세요."],
  ["category_id", "물품 구분을 선택하세요."],
  ["itemName", "물품명을 입력하세요."],
  ["owner", "소유자를 입력하세요."],
  ["ownerContact", "소유자 연락처를 입력하세요."],
];

export default function LostFormPage() {
  const navigate = useNavigate();
  const { manageNo } = useParams();
  const isEdit = Boolean(manageNo);
  const saved = isEdit ? getLostReport(manageNo) : null;

  const { form, setField, error, handleChange, checkRequired } =
    useRecordForm(() => (isEdit ? saved ?? emptyForm() : emptyForm()));

  if (isEdit && !saved) return <NotFoundBox manageNo={manageNo} />;

  function handleSubmit(e) {
    e.preventDefault();
    if (!checkRequired(REQUIRED_FIELDS)) return;

    const data = { ...form, category_id: Number(form.category_id) };
    if (isEdit) {
      updateLostReport(manageNo, data);
      navigate(`/lost/${manageNo}`, { replace: true });
    } else {
      addLostReport(data);
      navigate("/", { replace: true });
    }
  }

  function handleDelete() {
    if (window.confirm(`관리번호 ${manageNo} 건을 삭제하시겠습니까?`)) {
      deleteLostReport(manageNo);
      navigate("/");
    }
  }

  return (
    <div className="page">
      <form onSubmit={handleSubmit}>
        <PageHeader title={isEdit ? "분실 신고 수정" : "분실 신고"} />

        <ManageNoBar manageNo={isEdit ? manageNo : peekLostManageNo()} />

        {error && <p className="form-error">{error}</p>}

        <table className="grid record-grid">
          <tbody>
            <tr>
              <Field label="물품 구분" required>
                <select className="input" value={form.category_id}
                  onChange={(e) => setField("category_id", Number(e.target.value) || "")}>
                  <option value="">-- 선택 --</option>
                  {optionsFor(itemCategoryTable, form.category_id).map((c) => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </Field>
              <Field label="물품명" required>
                <input className="input" name="itemName" value={form.itemName} onChange={handleChange} />
              </Field>
              <Field label="처리 상태">
                <select className="input" name="status" value={form.status} onChange={handleChange}>
                  {PROCESS_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
              </Field>
            </tr>
            <tr>
              <Field label="접수일" required>
                <input className="input" type="date" name="receivedDate"
                  value={form.receivedDate} onChange={handleChange} />
              </Field>
              <Field label="습득일" required>
                <input className="input" type="date" name="foundDate"
                  value={form.foundDate} onChange={handleChange} />
              </Field>
              <Field label="처리일">
                <input className="input" type="date" name="processedDate"
                  value={form.processedDate} onChange={handleChange} />
              </Field>
            </tr>
            <tr>
              <Field label="소유자" required>
                <input className="input" name="owner" value={form.owner}
                  onChange={handleChange} placeholder="신고자 이름" />
              </Field>
              <Field label="소유자 연락처" required>
                <input className="input" value={form.ownerContact}
                  onChange={(e) => setField("ownerContact", formatPhone(e.target.value))}
                  placeholder="010-0000-0000" inputMode="numeric" />
              </Field>
              <Field label="확인자">
                <select className="input" name="checker" value={form.checker} onChange={handleChange}>
                  <option value="">-- 선택 --</option>
                  {STAFF_NAMES.map((n) => <option key={n} value={n}>{n}</option>)}
                </select>
              </Field>
            </tr>
            <tr>
              <Field label="특징" span={5}>
                <input className="input" name="feature" value={form.feature} onChange={handleChange} />
              </Field>
            </tr>
          </tbody>
        </table>

        <ActionBar>
          <button type="button" className="btn"
            onClick={() => navigate(isEdit ? `/lost/${manageNo}` : "/")}>취소</button>
          {isEdit && (
            <button type="button" className="btn danger" onClick={handleDelete}>삭제</button>
          )}
          <button type="submit" className="btn primary">{isEdit ? "저장" : "등록"}</button>
        </ActionBar>
      </form>
    </div>
  );
}
