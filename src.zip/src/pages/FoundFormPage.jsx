import { useNavigate, useParams } from "react-router-dom";
import {
  addFoundItem, getFoundItem, updateFoundItem, deleteFoundItem,
  peekFoundManageNo,
} from "../storage";
import {
  itemCategoryTable, processResultTable, optionsFor,
  computeDeadline, getDefaultResultId, getExpireAction,
} from "../settings";
import { STAFF_NAMES, CONTACTED_OPTIONS, DEFAULT_STORAGE_PLACE } from "../constants";
import { formatPhone } from "../imageUtil";
import { today } from "../dateUtil";
import { useRecordForm } from "../useRecordForm";
import Field from "../components/Field";
import PhotoCell from "../components/PhotoCell";
import PageHeader from "../components/PageHeader";
import ManageNoBar from "../components/ManageNoBar";
import ActionBar from "../components/ActionBar";
import NotFoundBox from "../components/NotFoundBox";

/** 새 접수 화면의 초기값. 물품구분·처리결과는 이름이 아니라 id 로 담는다. */
function emptyForm() {
  return {
    receivedDate: today(), foundDate: today(), category_id: "", itemName: "",
    feature: "", owner: "", ownerContact: "", contacted: CONTACTED_OPTIONS[0],
    storagePlace: DEFAULT_STORAGE_PLACE, result_id: getDefaultResultId(),
    checker: "", image: "",
  };
}

/** 필수 입력 항목과 안내 문구 */
const REQUIRED_FIELDS = [
  ["receivedDate", "접수일을 입력하세요."],
  ["foundDate", "습득일을 입력하세요."],
  ["category_id", "물품 구분을 선택하세요."],
  ["itemName", "물품명을 입력하세요."],
];

export default function FoundFormPage() {
  const navigate = useNavigate();
  const { manageNo } = useParams();
  const isEdit = Boolean(manageNo);
  const saved = isEdit ? getFoundItem(manageNo) : null;

  const {
    form, setField, error, handleChange, handleImage, removeImage, checkRequired,
  } = useRecordForm(() => (isEdit ? saved ?? emptyForm() : emptyForm()));

  // 보관기한은 계산 시점에 확정해 레코드에 저장한다(규칙 3).
  // 수정 화면에서는 접수일·물품구분이 실제로 바뀌었을 때만 다시 계산하고,
  // 그렇지 않으면 저장돼 있던 기한을 그대로 둔다.
  // (그래서 보관기간 설정을 바꿔도 기존 건의 기한은 변하지 않는다.)
  const deadlineInputsKept = isEdit && saved
    && saved.receivedDate === form.receivedDate
    && Number(saved.category_id) === Number(form.category_id);
  const deadline = deadlineInputsKept
    ? saved.deadline
    : computeDeadline(form.receivedDate, form.category_id);

  // 기간 만료 시 조치 방법은 지금의 설정값을 그대로 보여 준다(앞으로 취할 조치이므로).
  const expireAction = getExpireAction(form.category_id);

  if (isEdit && !saved) return <NotFoundBox manageNo={manageNo} />;

  function handleSubmit(e) {
    e.preventDefault();
    if (!checkRequired(REQUIRED_FIELDS)) return;

    const data = { ...form, category_id: Number(form.category_id), deadline };
    if (isEdit) {
      updateFoundItem(manageNo, data);
      navigate(`/found/${manageNo}`, { replace: true });
    } else {
      addFoundItem(data);
      navigate("/", { replace: true });
    }
  }

  function handleDelete() {
    if (window.confirm(`관리번호 ${manageNo} 건을 삭제하시겠습니까?`)) {
      deleteFoundItem(manageNo);
      navigate("/");
    }
  }

  return (
    <div className="page">
      <form onSubmit={handleSubmit}>
        <PageHeader title={isEdit ? "분실물 수정" : "분실물 접수"} />

        <ManageNoBar manageNo={isEdit ? manageNo : peekFoundManageNo()} />

        {error && <p className="form-error">{error}</p>}

        <table className="grid record-grid">
          <tbody>
            <tr>
              {/* 사진 칸은 항목 4줄 + 특징 1줄에 걸친다. */}
              <PhotoCell image={form.image} rowSpan={5}
                onPick={handleImage} onRemove={removeImage} />
              <Field label="물품 구분" required>
                <select className="input" value={form.category_id}
                  onChange={(e) => setField("category_id", Number(e.target.value) || "")}>
                  <option value="">-- 선택 --</option>
                  {optionsFor(itemCategoryTable, form.category_id).map((c) => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </Field>
              <Field label="물품명" required>
                <input className="input" name="itemName" value={form.itemName} onChange={handleChange} />
              </Field>
              <Field label="보관장소">
                <input className="input" name="storagePlace" value={form.storagePlace} onChange={handleChange} />
              </Field>
            </tr>
            <tr>
              <Field label="접수일" required>
                <input className="input" type="date" name="receivedDate"
                  value={form.receivedDate} onChange={handleChange} />
              </Field>
              <Field label="습득일" required>
                <input className="input" type="date" name="foundDate"
                  value={form.foundDate} onChange={handleChange} />
              </Field>
              <Field label="보관기한">
                <input className="input" value={deadline} readOnly disabled placeholder="자동 계산" />
              </Field>
            </tr>
            <tr>
              <Field label="소유자">
                <input className="input" name="owner" value={form.owner} onChange={handleChange} />
              </Field>
              <Field label="소유자 연락처">
                <input className="input" value={form.ownerContact}
                  onChange={(e) => setField("ownerContact", formatPhone(e.target.value))}
                  placeholder="010-0000-0000" inputMode="numeric" />
              </Field>
              <Field label="연락여부">
                <select className="input" name="contacted" value={form.contacted} onChange={handleChange}>
                  {CONTACTED_OPTIONS.map((o) => <option key={o} value={o}>{o}</option>)}
                </select>
              </Field>
            </tr>
            <tr>
              <Field label="처리결과">
                <select className="input" value={form.result_id ?? ""}
                  onChange={(e) => setField("result_id", Number(e.target.value))}>
                  {optionsFor(processResultTable, form.result_id).map((r) => (
                    <option key={r.id} value={r.id}>{r.name}</option>
                  ))}
                </select>
              </Field>
              <Field label="기간 만료 시 조치 방법">
                <input className="input" value={expireAction} readOnly disabled
                  placeholder="물품 구분 선택 시 표시" />
              </Field>
              <Field label="확인자">
                <select className="input" name="checker" value={form.checker} onChange={handleChange}>
                  <option value="">-- 선택 --</option>
                  {STAFF_NAMES.map((n) => <option key={n} value={n}>{n}</option>)}
                </select>
              </Field>
            </tr>
            <tr>
              <Field label="특징" span={5}>
                <input className="input" name="feature" value={form.feature} onChange={handleChange} />
              </Field>
            </tr>
          </tbody>
        </table>

        <ActionBar>
          <button type="button" className="btn"
            onClick={() => navigate(isEdit ? `/found/${manageNo}` : "/")}>취소</button>
          {isEdit && (
            <button type="button" className="btn danger" onClick={handleDelete}>삭제</button>
          )}
          <button type="submit" className="btn primary">{isEdit ? "저장" : "등록"}</button>
        </ActionBar>
      </form>
    </div>
  );
}
